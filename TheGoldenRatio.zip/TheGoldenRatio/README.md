In mathematics, two quantities are in the golden ratio if their ratio is the same as the ratio of their sum to the larger of the two quantities. The figure on the right illustrates the geometric relationship. Expressed algebraically, for quantities a and b with a > b > 0,

The golden ratio is also called the golden mean or golden section (Latin: sectio aurea). Other names include extreme and mean ratio, medial section, divine proportion


--wikipedia

